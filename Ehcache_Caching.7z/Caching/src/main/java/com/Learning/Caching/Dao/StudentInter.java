package com.Learning.Caching.Dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.Learning.Caching.Entity.Student;

public interface StudentInter extends CrudRepository<Student, Integer>{

	 Optional<Student> findByEmail(String email);
}

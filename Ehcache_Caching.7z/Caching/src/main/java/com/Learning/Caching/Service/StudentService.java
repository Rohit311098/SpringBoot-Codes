package com.Learning.Caching.Service;

import org.hibernate.annotations.Cache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.Learning.Caching.Dao.StudentDao;
import com.Learning.Caching.Entity.Student;

@Service
public class StudentService {
	
	@Autowired
	private StudentDao dao;

	@Cacheable(cacheNames = "myCache", key = "#id",unless ="#result == null")
	public Student getstudent(int id) {
		
		Student s=dao.getStudent(id);
		return s;
	}

	public boolean addstudent(Student s) {
		boolean added=dao.addstudent(s);
		return added;
	}

	@CachePut(cacheNames = "myCache", key = "#id")
	public Student updatestudent(int id,Student s) {
		Student updated=dao.updatestudent(id,s);
		return updated;
	}

	@CacheEvict(cacheNames = "myCache", key = "#id")
	public boolean deletestudent(int id) {
		boolean deleted=dao.deletestudent(id);
		return deleted;
	}
}

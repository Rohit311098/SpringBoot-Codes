package com.Learning.Caching.Dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.Learning.Caching.Entity.Student;

@Component
public class StudentDao {
	
	@Autowired
	StudentInter db;

	public Student getStudent(int id) {
		
		System.out.println("Getting student from the database");
		
		Optional<Student> s=db.findById(id);
		if(s.isPresent()) return s.get();
		return null;
	}

	public boolean addstudent(Student s) {
		System.out.println("Adding student in the database");
		db.save(s);
		return true;
	}

	public Student updatestudent(int id,Student s) {
		System.out.println("updating student in the database");
		Optional<Student> existingStudent = db.findById(id);
	    
	    if (existingStudent.isPresent()) {
	        Student student = existingStudent.get();
	        student.setName(s.getName());
	        student.setAge(s.getAge());
	        student.setEnrollmentDate(s.getEnrollmentDate());
	        
	        return db.save(student);
	    } else {
	        return null; // Student does not exist
	    }
	}

	public boolean deletestudent(int id) {
		System.out.println("Deleting student from the database");
		db.deleteById(id);
		return true;
	}

}

package com.Learning.Caching.Controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Learning.Caching.Entity.Student;
import com.Learning.Caching.Service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	StudentService service;
	
	@RequestMapping(value = "/getstudent/{sid}")
	public ResponseEntity<Object> getStudent(@PathVariable("sid") int id)
	{
		Student s=service.getstudent(id);
		if (s == null) {
	        // Return JSON message instead of raw string
	        Map<String, String> response = new HashMap<>();
	        response.put("message", "No student found");
	        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	    }
		
		return ResponseEntity.ok(s);
	}
	
	
	@RequestMapping(value = "/addstudent")
	public ResponseEntity<Object> addStudent(@RequestBody Student s)
	{
		boolean isadded=service.addstudent(s);
		if (!isadded) {
	        // Return JSON message instead of raw string
	        Map<String, String> response = new HashMap<>();
	        response.put("message", "Student not added");
	        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	    }
		
		return new ResponseEntity<>(s,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/updatestudent/{id}")
	public ResponseEntity<Object> updateStudent(@PathVariable int id,@RequestBody Student s)
	{
		Student updatedstudent=service.updatestudent(id,s);
		if (updatedstudent==null) {
	        // Return JSON message instead of raw string
	        Map<String, String> response = new HashMap<>();
	        response.put("message", "Student didn't got  updated");
	        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	    }
		return ResponseEntity.ok(s);
	}
	
	@RequestMapping(value = "/deletestudent/{id}")
	public ResponseEntity<Object> deleteStudent(@PathVariable("id") int id)
	{
		boolean isdeleted=service.deletestudent(id);
		if(!isdeleted)
		{
			 // Return JSON message instead of raw string
	        Map<String, String> response = new HashMap<>();
	        response.put("message", "Student didn't got deleted");
	        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok("Student deleted succesfully");
	}
}
